// ============================================================================
// API CLIENT SERVICE - apiClient.js
// ============================================================================
// Centralized API communication with auth handling, interceptors, and error management

class APIClient {
  constructor(baseURL = process.env.REACT_APP_API_URL || 'http://localhost:5000') {
    this.baseURL = baseURL;
    this.timeout = 30000; // 30 seconds
    this.headers = {
      'Content-Type': 'application/json',
    };
    this.interceptors = {
      request: [],
      response: [],
      error: [],
    };
  }

  /**
   * Get authorization token from localStorage
   */
  getToken() {
    return localStorage.getItem('studypal_token');
  }

  /**
   * Set authorization token
   */
  setToken(token) {
    localStorage.setItem('studypal_token', token);
    this.headers.Authorization = `Bearer ${token}`;
  }

  /**
   * Clear authorization token
   */
  clearToken() {
    localStorage.removeItem('studypal_token');
    delete this.headers.Authorization;
  }

  /**
   * Add request interceptor
   */
  addRequestInterceptor(callback) {
    this.interceptors.request.push(callback);
    return this;
  }

  /**
   * Add response interceptor
   */
  addResponseInterceptor(callback) {
    this.interceptors.response.push(callback);
    return this;
  }

  /**
   * Add error interceptor
   */
  addErrorInterceptor(callback) {
    this.interceptors.error.push(callback);
    return this;
  }

  /**
   * Execute request interceptors
   */
  async executeRequestInterceptors(config) {
    let processedConfig = config;
    for (const interceptor of this.interceptors.request) {
      processedConfig = await interceptor(processedConfig);
    }
    return processedConfig;
  }

  /**
   * Execute response interceptors
   */
  async executeResponseInterceptors(response) {
    let processedResponse = response;
    for (const interceptor of this.interceptors.response) {
      processedResponse = await interceptor(processedResponse);
    }
    return processedResponse;
  }

  /**
   * Execute error interceptors
   */
  async executeErrorInterceptors(error) {
    let processedError = error;
    for (const interceptor of this.interceptors.error) {
      processedError = await interceptor(processedError);
    }
    return processedError;
  }

  /**
   * Make HTTP request
   */
  async request(method, endpoint, data = null, customHeaders = {}) {
    const url = this.baseURL + endpoint;
    const token = this.getToken();

    let config = {
      method,
      headers: {
        ...this.headers,
        ...customHeaders,
        ...(token && { Authorization: `Bearer ${token}` }),
      },
    };

    if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
      config.body = JSON.stringify(data);
    }

    // Execute request interceptors
    config = await this.executeRequestInterceptors(config);

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.timeout);

      const response = await fetch(url, {
        ...config,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      // Parse response
      let responseData;
      try {
        responseData = await response.json();
      } catch {
        responseData = await response.text();
      }

      // Handle errors
      if (!response.ok) {
        const error = new APIError(
          responseData?.error || response.statusText || 'Unknown error',
          response.status,
          responseData
        );

        // Execute error interceptors
        await this.executeErrorInterceptors(error);
        throw error;
      }

      // Execute response interceptors
      const finalResponse = await this.executeResponseInterceptors(responseData);
      return finalResponse;
    } catch (error) {
      if (error instanceof APIError) {
        throw error;
      }

      const apiError = new APIError(
        error.message || 'Network error',
        0,
        error
      );

      await this.executeErrorInterceptors(apiError);
      throw apiError;
    }
  }

  /**
   * GET request
   */
  get(endpoint, customHeaders = {}) {
    return this.request('GET', endpoint, null, customHeaders);
  }

  /**
   * POST request
   */
  post(endpoint, data, customHeaders = {}) {
    return this.request('POST', endpoint, data, customHeaders);
  }

  /**
   * PUT request
   */
  put(endpoint, data, customHeaders = {}) {
    return this.request('PUT', endpoint, data, customHeaders);
  }

  /**
   * PATCH request
   */
  patch(endpoint, data, customHeaders = {}) {
    return this.request('PATCH', endpoint, data, customHeaders);
  }

  /**
   * DELETE request
   */
  delete(endpoint, customHeaders = {}) {
    return this.request('DELETE', endpoint, null, customHeaders);
  }
}

/**
 * Custom Error Class for API errors
 */
class APIError extends Error {
  constructor(message, status = 0, data = null) {
    super(message);
    this.name = 'APIError';
    this.status = status;
    this.data = data;
  }

  isUnauthorized() {
    return this.status === 401;
  }

  isForbidden() {
    return this.status === 403;
  }

  isNotFound() {
    return this.status === 404;
  }

  isValidationError() {
    return this.status === 400;
  }

  isServerError() {
    return this.status >= 500;
  }
}

// ============================================================================
// API ENDPOINTS DEFINITION
// ============================================================================

export const API_ENDPOINTS = {
  // Authentication
  AUTH: {
    SIGNUP: '/api/auth/signup',
    LOGIN: '/api/auth/login',
    LOGOUT: '/api/auth/logout',
    REFRESH: '/api/auth/refresh',
  },

  // AI Tutor
  TUTOR: {
    ASK: '/api/tutor/ask',
    HISTORY: '/api/tutor/history',
    CLEAR_HISTORY: '/api/tutor/history/clear',
  },

  // Quiz
  QUIZ: {
    GENERATE: '/api/quiz/generate',
    SUBMIT: '/api/quiz/submit',
    GET_RESULTS: '/api/quiz/results',
  },

  // Summarizer
  SUMMARIZER: {
    SUMMARIZE: '/api/summarizer/summarize',
  },

  // Study Planner
  PLANNER: {
    GENERATE: '/api/planner/generate',
    GET_PLANS: '/api/planner/plans',
    UPDATE_PLAN: (id) => `/api/planner/plans/${id}`,
    DELETE_PLAN: (id) => `/api/planner/plans/${id}`,
  },

  // Subscription
  SUBSCRIPTION: {
    UPGRADE: '/api/subscription/upgrade',
    CANCEL: '/api/subscription/cancel',
    STATUS: '/api/subscription/status',
  },

  // Admin
  ADMIN: {
    STATS: '/api/admin/stats',
    ANALYTICS: '/api/admin/analytics',
    USERS: '/api/admin/users',
    USER_DETAIL: (id) => `/api/admin/users/${id}`,
  },
};

// ============================================================================
// INITIALIZE API CLIENT
// ============================================================================

const apiClient = new APIClient();

// Add default request interceptor for auth
apiClient.addRequestInterceptor((config) => {
  const token = localStorage.getItem('studypal_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Add response interceptor for token refresh
apiClient.addResponseInterceptor((response) => {
  return response;
});

// Add error interceptor for handling 401 (unauthorized)
apiClient.addErrorInterceptor((error) => {
  if (error.isUnauthorized()) {
    localStorage.removeItem('studypal_token');
    localStorage.removeItem('studypal_user');
    // Optionally redirect to login
    // window.location.href = '/login';
  }
  return error;
});

// ============================================================================
// API SERVICE METHODS
// ============================================================================

export const authService = {
  signup: (name, email, password) =>
    apiClient.post(API_ENDPOINTS.AUTH.SIGNUP, { name, email, password }),
  
  login: (email, password) =>
    apiClient.post(API_ENDPOINTS.AUTH.LOGIN, { email, password }),
  
  logout: () => {
    apiClient.clearToken();
    return Promise.resolve();
  },

  setToken: (token) => apiClient.setToken(token),
};

export const tutorService = {
  ask: (question, level = 'intermediate') =>
    apiClient.post(API_ENDPOINTS.TUTOR.ASK, { question, level }),
  
  getHistory: () =>
    apiClient.get(API_ENDPOINTS.TUTOR.HISTORY),
  
  clearHistory: () =>
    apiClient.delete(API_ENDPOINTS.TUTOR.CLEAR_HISTORY),
};

export const quizService = {
  generate: (topic, numQuestions = 10, level = 'intermediate') =>
    apiClient.post(API_ENDPOINTS.QUIZ.GENERATE, { topic, numQuestions, level }),
  
  submit: (topic, answers, totalQuestions) =>
    apiClient.post(API_ENDPOINTS.QUIZ.SUBMIT, { topic, answers, totalQuestions }),
  
  getResults: () =>
    apiClient.get(API_ENDPOINTS.QUIZ.GET_RESULTS),
};

export const summarizerService = {
  summarize: (notes) =>
    apiClient.post(API_ENDPOINTS.SUMMARIZER.SUMMARIZE, { notes }),
};

export const plannerService = {
  generate: (subjects, hoursPerDay, examDate, priority = 'balanced') =>
    apiClient.post(API_ENDPOINTS.PLANNER.GENERATE, {
      subjects,
      hoursPerDay,
      examDate,
      priority,
    }),
  
  getPlans: () =>
    apiClient.get(API_ENDPOINTS.PLANNER.GET_PLANS),
  
  updatePlan: (id, data) =>
    apiClient.put(API_ENDPOINTS.PLANNER.UPDATE_PLAN(id), data),
  
  deletePlan: (id) =>
    apiClient.delete(API_ENDPOINTS.PLANNER.DELETE_PLAN(id)),
};

export const subscriptionService = {
  upgrade: (paymentMethod = 'card') =>
    apiClient.post(API_ENDPOINTS.SUBSCRIPTION.UPGRADE, { paymentMethod }),
  
  cancel: () =>
    apiClient.post(API_ENDPOINTS.SUBSCRIPTION.CANCEL),
  
  getStatus: () =>
    apiClient.get(API_ENDPOINTS.SUBSCRIPTION.STATUS),
};

export const adminService = {
  getStats: () =>
    apiClient.get(API_ENDPOINTS.ADMIN.STATS),
  
  getAnalytics: () =>
    apiClient.get(API_ENDPOINTS.ADMIN.ANALYTICS),
  
  getUsers: () =>
    apiClient.get(API_ENDPOINTS.ADMIN.USERS),
  
  getUserDetail: (id) =>
    apiClient.get(API_ENDPOINTS.ADMIN.USER_DETAIL(id)),
};

// ============================================================================
// ERROR HANDLING UTILITIES
// ============================================================================

export const handleAPIError = (error) => {
  if (error instanceof APIError) {
    const message = error.message;

    if (error.isUnauthorized()) {
      return 'Please log in again';
    }
    if (error.isForbidden()) {
      return 'You don\'t have permission to do this';
    }
    if (error.isNotFound()) {
      return 'The requested resource was not found';
    }
    if (error.isValidationError()) {
      return `Validation error: ${message}`;
    }
    if (error.isServerError()) {
      return 'Server error. Please try again later';
    }

    return message;
  }

  return 'An unexpected error occurred';
};

export default apiClient;
export { APIError };
