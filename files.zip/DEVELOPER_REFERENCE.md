# 🚀 StudyPal AI - Developer Quick Reference

## Quick Start Commands

```bash
# Frontend
npm start              # Run dev server (port 3000)
npm run build         # Production build
npm test              # Run tests

# Backend
npm start             # Run API server (port 5000)
npm run dev          # Dev with nodemon
npm test             # Run tests

# Docker
docker-compose up -d  # Start all services
docker-compose down   # Stop all services
docker-compose logs   # View logs
```

---

## Project Structure Quick Lookup

```
studypal-ai/
├── frontend/
│   ├── src/App.jsx           ← Main component (all features here)
│   ├── hooks/                ← useAuth, useApi, useDailyLimit, etc.
│   └── services/apiClient.js ← API communication
├── backend/
│   ├── server.js             ← Express app, models, routes
│   ├── package.json
│   └── .env                  ← Configuration
└── Documentation/
    ├── README.md             ← Overview
    ├── SETUP_GUIDE.md        ← Installation
    └── DEPLOYMENT_GUIDE.md   ← Hosting
```

---

## Frontend Architecture

### Components Hierarchy
```
StudyPalAI (Main)
├── LandingPage
│   ├── Features
│   ├── Pricing
│   └── CTA
├── LoginPage
├── SignupPage
└── Dashboard (when authenticated)
    ├── Sidebar (Navigation)
    └── Main Content
        ├── Dashboard (Stats)
        ├── ChatTutor (AI chat)
        ├── QuizGenerator
        ├── NoteSummarizer
        ├── StudyPlanner
        ├── ExamPrep
        ├── AdminDashboard
        └── SettingsPage
```

### Key Hooks
```javascript
// Authentication
const { user, login, signup, logout } = useAuth();

// API calls
const { data, loading, error, fetch } = useApi(url);

// Daily limit tracking
const { questionsUsed, canAskQuestion } = useDailyQuestionLimit();

// UI state
const isMobile = useMediaQuery('(max-width: 768px)');
```

### Custom API Client
```javascript
import { authService, tutorService } from './apiClient';

// Services available:
authService.login(email, password)
authService.signup(name, email, password)
tutorService.ask(question, level)
tutorService.getHistory()
quizService.generate(topic, numQuestions)
plannerService.generate(subjects, hoursPerDay, examDate)
adminService.getStats()
```

---

## Backend Architecture

### Models
```javascript
User {
  name, email, password, plan,
  dailyQuestions, totalQuestions,
  chatHistory[], quizzes[], studyPlans[]
}

Payment {
  userId, amount, plan, status, transactionId
}

Analytics {
  date, totalUsers, activeUsers, revenue
}
```

### Routes Structure
```
/api/auth/
  POST /signup
  POST /login

/api/tutor/
  POST /ask
  GET /history

/api/quiz/
  POST /generate
  POST /submit

/api/planner/
  POST /generate
  GET /plans

/api/admin/
  GET /stats
  GET /analytics
  GET /users
```

### Middleware Chain
```
Request
  ↓
CORS Check
  ↓
Body Parser
  ↓
Auth Middleware (if protected)
  ↓
Route Handler
  ↓
Error Handler
  ↓
Response
```

---

## Common Tasks

### 1. Add a New Feature

**Frontend:**
```javascript
// 1. Create component
function MyFeature({ currentUser }) {
  const { data, fetch } = useApi('/api/feature/endpoint');
  
  return (
    <div className="...">
      {/* UI */}
    </div>
  );
}

// 2. Add to sidebar navigation
{ id: 'myfeature', label: 'My Feature', icon: Icon }

// 3. Add to page router
if (currentPage === 'myfeature') 
  return <MyFeature currentUser={currentUser} />;
```

**Backend:**
```javascript
// 1. Create route
app.post('/api/feature/endpoint', authenticateToken, async (req, res) => {
  // Business logic
  res.json({ result });
});

// 2. Add API endpoint to frontend
API_ENDPOINTS.FEATURE = {
  ENDPOINT: '/api/feature/endpoint',
};
```

### 2. Add Authentication Check

```javascript
// Frontend
const [currentUser, setCurrentUser] = useState(null);

// If no user, show login page
if (!currentUser) {
  return <LoginPage onLogin={handleLogin} />;
}

// Backend
const authenticateToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid' });
    req.user = user;
    next();
  });
};
```

### 3. Handle Free Plan Limits

```javascript
// Check daily limit
if (currentUser.plan === 'Free' && currentUser.dailyQuestions >= 10) {
  // Show paywall message
  return showPaywall();
}

// Increment counter
currentUser.dailyQuestions++;
```

### 4. Call Claude API

```javascript
const Anthropic = require('@anthropic-ai/sdk');
const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY
});

const response = await client.messages.create({
  model: 'claude-3-5-sonnet-20241022',
  max_tokens: 1024,
  messages: [{
    role: 'user',
    content: userQuestion
  }]
});

return response.content[0].text;
```

### 5. Process Payment

```javascript
// Flutterwave
FlutterwaveCheckout({
  public_key: 'FLWPUBK_...',
  amount: 2999,
  callback: async (response) => {
    if (response.status === 'successful') {
      await apiClient.post('/api/subscription/upgrade', {
        transactionId: response.transaction_id
      });
    }
  }
});
```

---

## Environment Variables Checklist

### Frontend (.env)
```
REACT_APP_API_URL=http://localhost:5000
REACT_APP_ANTHROPIC_API_KEY=sk-ant-...
```

### Backend (.env)
```
MONGODB_URI=mongodb+srv://...
JWT_SECRET=your-secret-key
ANTHROPIC_API_KEY=sk-ant-...
FLUTTERWAVE_PUBLIC_KEY=FLWPUBK_...
FLUTTERWAVE_SECRET_KEY=FLWSECK_...
PORT=5000
NODE_ENV=development
```

---

## Styling & UI

### Tailwind Classes Used
```javascript
// Colors
bg-slate-950, bg-slate-900, bg-slate-800
bg-indigo-600, bg-purple-600
text-white, text-slate-300

// Responsive
sm:, md:, lg:
w-full, sm:w-1/2, lg:w-1/3

// Effects
rounded-lg, shadow-lg
hover:, transition
```

### Component Patterns
```javascript
// Card
<div className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl">

// Button primary
<button className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:shadow-lg">

// Button secondary
<button className="px-4 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700">
```

---

## Testing

### Frontend Test Example
```javascript
import { render, screen } from '@testing-library/react';
import LoginPage from './LoginPage';

test('renders login form', () => {
  render(<LoginPage />);
  expect(screen.getByPlaceholderText(/email/i)).toBeInTheDocument();
});
```

### Backend Test Example
```javascript
const request = require('supertest');
const app = require('./server');

describe('Auth Routes', () => {
  test('POST /api/auth/signup', async () => {
    const res = await request(app)
      .post('/api/auth/signup')
      .send({ email: 'test@test.com', password: 'pass' });
    
    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty('token');
  });
});
```

---

## API Testing

### Using cURL
```bash
# Signup
curl -X POST http://localhost:5000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"test123","name":"Test"}'

# Ask question (with token)
curl -X POST http://localhost:5000/api/tutor/ask \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"question":"What is photosynthesis?","level":"beginner"}'
```

### Using Postman
1. Create collection
2. Add requests
3. Set environment variables ({{base_url}}, {{token}})
4. Use pre-request scripts for auth
5. Save responses as examples

---

## Debugging

### Browser DevTools
```javascript
// Check stored data
localStorage.getItem('studypal_user')
localStorage.getItem('studypal_token')

// Monitor network
Network tab → see all API calls
Console → check errors
Storage → verify data persistence
```

### Backend Debugging
```bash
# Add console logs
console.log('User:', user);

# Use debugger
node --inspect server.js
# Visit chrome://inspect

# Use VS Code debugger
# Add breakpoints in editor
# F5 to start debugging
```

---

## Performance Tips

### Frontend
- Use `React.memo()` for components
- Lazy load routes with `React.lazy()`
- Memoize callbacks with `useCallback`
- Debounce search inputs
- Optimize images

### Backend
- Add database indexes
- Use connection pooling
- Implement caching
- Compress responses (gzip)
- Limit query results

---

## Security Checklist

Before pushing to production:
- [ ] All secrets in .env (not in code)
- [ ] HTTPS enabled
- [ ] CORS properly configured
- [ ] Input validation on backend
- [ ] Rate limiting enabled
- [ ] Password hashing (bcrypt)
- [ ] JWT expiry set
- [ ] Helmet security headers
- [ ] No console.logs in production
- [ ] Error messages don't leak info

---

## Useful Links

- **React Docs**: https://react.dev
- **Express Docs**: https://expressjs.com
- **MongoDB Docs**: https://docs.mongodb.com
- **Tailwind CSS**: https://tailwindcss.com
- **Anthropic API**: https://docs.anthropic.com
- **Flutterwave Docs**: https://developer.flutterwave.com

---

## Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| CORS error | Add origin to `ALLOWED_ORIGINS` in .env |
| API timeout | Increase `timeout` in apiClient.js |
| Token expired | Refresh token or re-login |
| Memory leak | Clean up listeners in useEffect cleanup |
| DB too slow | Add indexes or optimize queries |
| Build fails | Clear node_modules, npm install |

---

## Git Workflow

```bash
# Create feature branch
git checkout -b feature/new-feature

# Make changes
git add .
git commit -m "feat: add new feature"

# Push to remote
git push origin feature/new-feature

# Create Pull Request
# Wait for review
# Merge to main
```

---

## Deployment Checklist

Before deploying:
- [ ] All tests passing
- [ ] No console errors
- [ ] Environment variables configured
- [ ] Database backup taken
- [ ] Frontend build optimized
- [ ] Backend dependencies updated
- [ ] API endpoints tested
- [ ] SSL certificate valid
- [ ] DNS configured
- [ ] Monitoring enabled

---

**Need Help?** See [SETUP_GUIDE.md](./SETUP_GUIDE.md) or [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md)

**Last Updated**: January 2024
