# 🚀 StudyPal AI - Deployment Guide

Complete guide to deploy StudyPal AI on popular platforms.

## Table of Contents
1. [Vercel (Frontend)](#vercel-frontend)
2. [Render (Backend)](#render-backend)
3. [Railway (Backend Alternative)](#railway-backend-alternative)
4. [Heroku (Backend Alternative)](#heroku-backend-alternative)
5. [AWS (Production)](#aws-production)
6. [DigitalOcean (VPS)](#digitalocean-vps)

---

## Vercel (Frontend)

### Easiest Method - GitHub Integration

1. **Push to GitHub**
```bash
git push origin main
```

2. **Connect to Vercel**
   - Go to https://vercel.com
   - Click "New Project"
   - Select your GitHub repository
   - Vercel auto-detects React

3. **Configure Environment**
   - Go to Settings → Environment Variables
   - Add:
     ```
     REACT_APP_API_URL=https://studypal-api.render.com
     REACT_APP_ANTHROPIC_API_KEY=sk-ant-...
     ```

4. **Deploy**
   - Click "Deploy"
   - Vercel builds and deploys automatically
   - Get URL: `https://studypal-ai.vercel.app`

### Custom Domain
1. Go to Settings → Domains
2. Add your domain (e.g., app.studypal.ai)
3. Update DNS records at registrar
4. Vercel provides DNS configuration

---

## Render (Backend)

### Step 1: Prepare Repository
```bash
# Ensure Dockerfile exists in backend/
# Ensure .env.example exists
# Commit everything
git add .
git commit -m "Ready for deployment"
git push origin main
```

### Step 2: Create Render Account
- Go to https://render.com
- Sign up with GitHub
- Link your GitHub account

### Step 3: Create Web Service
1. Click "New +" → "Web Service"
2. Select your repository
3. Configure:
   - **Name**: `studypal-api`
   - **Environment**: Docker
   - **Region**: Choose nearest
   - **Plan**: Starter (free tier available)

### Step 4: Add Environment Variables
In Render Dashboard:
```
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/studypal
JWT_SECRET=your-super-secret-key
ANTHROPIC_API_KEY=sk-ant-...
FLUTTERWAVE_PUBLIC_KEY=FLWPUBK_...
FLUTTERWAVE_SECRET_KEY=FLWSECK_...
NODE_ENV=production
PORT=5000
```

### Step 5: Deploy
- Click "Deploy"
- Render builds from Dockerfile
- Get URL: `https://studypal-api.onrender.com`

### Step 6: Update Frontend
Update `REACT_APP_API_URL` in Vercel:
```
https://studypal-api.onrender.com
```

---

## Railway (Backend Alternative)

### Step 1: Create Account
- Go to https://railway.app
- Sign up with GitHub

### Step 2: Create New Project
1. Click "New Project"
2. Select "Deploy from GitHub"
3. Select your repository

### Step 3: Configure
```bash
# In Railway Dashboard:
# Settings → Environment
# Add:
MONGODB_URI=mongodb+srv://...
JWT_SECRET=...
ANTHROPIC_API_KEY=...
```

### Step 4: Deploy
- Railway auto-detects Node.js
- Creates container from Dockerfile
- Get domain automatically

---

## Heroku (Backend Alternative)

### Note
Heroku free tier discontinued. Use paid tier or alternatives.

### For Reference (Paid Heroku):
```bash
# Install Heroku CLI
brew tap heroku/brew && brew install heroku

# Login
heroku login

# Create app
heroku create studypal-api

# Set environment variables
heroku config:set MONGODB_URI=mongodb+srv://...
heroku config:set JWT_SECRET=...
heroku config:set ANTHROPIC_API_KEY=...

# Deploy
git push heroku main

# View logs
heroku logs --tail
```

---

## AWS (Production)

### Recommended Architecture
```
Route 53 (DNS)
    ↓
CloudFront (CDN)
    ├→ S3 (Frontend static files)
    └→ ALB (Load Balancer)
         └→ ECS (Docker containers)
              └→ RDS (MongoDB alternative - DocumentDB)
```

### Step 1: Frontend (S3 + CloudFront)

```bash
# Build frontend
cd frontend
npm run build

# Create S3 bucket
aws s3 mb s3://studypal-ai-frontend

# Upload files
aws s3 sync build/ s3://studypal-ai-frontend/ --delete

# Create CloudFront distribution
# AWS Console → CloudFront → Create Distribution
# Origin: S3 bucket
# CNAME: app.studypal.ai
```

### Step 2: Backend (ECS + RDS)

```bash
# Create ECR repository
aws ecr create-repository --repository-name studypal-api

# Build and push image
aws ecr get-login-password | docker login --username AWS --password-stdin ...
docker build -t studypal-api .
docker tag studypal-api:latest xxx.dkr.ecr.region.amazonaws.com/studypal-api:latest
docker push xxx.dkr.ecr.region.amazonaws.com/studypal-api:latest
```

### Step 3: Create RDS MongoDB Alternative

Use AWS DocumentDB (MongoDB compatible):
```bash
# AWS Console → DocumentDB
# Create cluster
# Get connection string
# Add to ECS environment
```

### Step 4: ECS Fargate

```bash
# Create ECS cluster
aws ecs create-cluster --cluster-name studypal

# Create task definition
# Register container: studypal-api
# Memory: 512 MB
# CPU: 256
# Port: 5000
```

### Step 5: Application Load Balancer

```bash
# Create ALB
# Target: ECS service
# Health check: /health
# HTTPS listener: app.studypal.ai → 443
```

### Cost Estimate
- S3: $0.023/GB stored
- CloudFront: $0.085/GB transferred
- ECS Fargate: $0.04664/vCPU/hour
- DocumentDB: $1.10/hour
- **Total**: ~$100-300/month

---

## DigitalOcean (VPS)

### Step 1: Create Droplet
```bash
# Create Ubuntu 22.04 droplet ($6/month)
# Size: Basic (2GB RAM, 1 vCPU)
```

### Step 2: SSH into Server
```bash
ssh root@your_server_ip
```

### Step 3: Install Dependencies
```bash
# Update system
apt update && apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt install -y nodejs

# Install Docker
curl -sSL https://get.docker.com | sh
usermod -aG docker root

# Install Docker Compose
curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
```

### Step 4: Clone Repository
```bash
git clone https://github.com/your-repo/studypal-ai.git
cd studypal-ai

# Configure .env
cp .env.example .env
nano .env  # Edit with your keys
```

### Step 5: Start Services
```bash
docker-compose up -d

# Verify
docker-compose ps
```

### Step 6: Setup Nginx Reverse Proxy
```bash
# Install Nginx
apt install -y nginx

# Create config
cat > /etc/nginx/sites-available/studypal << 'EOF'
upstream backend {
    server localhost:5000;
}

server {
    listen 80;
    server_name api.studypal.ai;

    location / {
        proxy_pass http://backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

# Enable site
ln -s /etc/nginx/sites-available/studypal /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

### Step 7: SSL Certificate (Let's Encrypt)
```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d api.studypal.ai
```

### Step 8: Auto-restart on Reboot
```bash
# Add to crontab
crontab -e

# Add line:
@reboot cd /path/to/studypal-ai && docker-compose up -d
```

### Cost Estimate
- Droplet: $6/month
- Domain: $12/year
- Storage: Included
- **Total**: ~$72/year

---

## Database Deployment

### MongoDB Atlas (Recommended)

1. Go to https://cloud.mongodb.com
2. Create free cluster
3. Whitelist IPs
4. Get connection string:
   ```
   mongodb+srv://user:pass@cluster.mongodb.net/studypal
   ```

### Self-hosted MongoDB

```bash
# Create MongoDB container
docker run -d \
  --name mongo \
  -e MONGO_INITDB_ROOT_USERNAME=admin \
  -e MONGO_INITDB_ROOT_PASSWORD=password \
  -p 27017:27017 \
  -v mongo_data:/data/db \
  mongo:6.0
```

---

## CI/CD Pipeline

### GitHub Actions (Automated Deployment)

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy StudyPal AI

on:
  push:
    branches: [main]

jobs:
  deploy-frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: cd frontend && npm install && npm run build
      - uses: actions/upload-artifact@v3
        with:
          name: frontend-build
          path: frontend/build

  deploy-backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Push to Docker Hub
        run: |
          docker login -u ${{ secrets.DOCKER_USER }} -p ${{ secrets.DOCKER_PASS }}
          docker build -t ${{ secrets.DOCKER_USER }}/studypal-api .
          docker push ${{ secrets.DOCKER_USER }}/studypal-api
      - name: Deploy to Render
        run: curl -X POST ${{ secrets.RENDER_WEBHOOK }}
```

---

## Domain Configuration

### DNS Setup
```
Domain Registrar (GoDaddy, Namecheap, etc.)

A Record:
  Name: app
  Value: Vercel IP (auto)

CNAME Record:
  Name: api
  Value: studypal-api.onrender.com

MX Record (for emails):
  priority 10: mail.studypal.ai
```

### SSL Certificate
- **Vercel**: Automatic
- **Render**: Automatic
- **Custom Server**: Let's Encrypt (free)

---

## Monitoring & Logs

### View Logs
```bash
# Vercel
vercel logs

# Render
render logs

# Local Docker
docker-compose logs -f api
docker-compose logs -f mongo
```

### Health Checks
```bash
# Frontend
curl https://app.studypal.ai

# Backend
curl https://api.studypal.ai/health

# Database
mongosh "mongodb+srv://..." --eval "db.adminCommand('ping')"
```

---

## Scaling

### Horizontal Scaling (Multiple Instances)

**Render:**
```yaml
# Dashboard → Settings → Instance Type
# Upgrade to paid plan for multiple instances
```

**Docker Compose:**
```bash
# Scale backend to 3 instances
docker-compose up -d --scale api=3
```

---

## Backup & Recovery

### Database Backup
```bash
# MongoDB Atlas automatic backups (Daily)
# Settings → Backup

# Manual backup
mongodump --uri "mongodb+srv://..." --out ./backup
```

### Application Backup
```bash
# GitHub is your backup
# All code is version controlled
# Use GitHub releases for stable versions
```

---

## Performance Optimization

### Frontend
```bash
# Build optimization
npm run build

# Analyze bundle
npm install -g source-map-explorer
source-map-explorer 'build/static/js/*.js'
```

### Backend
```bash
# Enable gzip compression
# Add caching headers
# Use database indexes
```

### CDN
- Vercel automatically uses Vercel's Edge Network
- CloudFront for S3 static files
- Add caching headers to backend

---

## Security Checklist

- [ ] All environment variables set
- [ ] HTTPS enabled on all domains
- [ ] Database backup automated
- [ ] Rate limiting enabled
- [ ] CORS properly configured
- [ ] Admin password changed
- [ ] SSL certificate valid
- [ ] Firewall rules configured
- [ ] API keys rotated
- [ ] Monitoring enabled

---

## Troubleshooting

### Application not starting
```bash
# Check logs
docker-compose logs api

# Check ports
sudo lsof -i :5000
sudo lsof -i :3000

# Restart
docker-compose restart
```

### Database connection error
```bash
# Verify connection string
# Check IP whitelist in MongoDB Atlas
# Verify credentials
```

### High memory usage
```bash
# Check running processes
docker stats

# Increase limits
# Implement caching
# Optimize queries
```

---

## Cost Comparison

| Platform | Frontend | Backend | Database | Monthly |
|----------|----------|---------|----------|---------|
| Vercel + Render + Atlas | Free | Free | Free | ~$0 |
| AWS | $1 | $30+ | $0 | $31+ |
| DigitalOcean | Included | Included | Included | $6-12 |
| Heroku | N/A | $50+ | $9+ | $59+ |

**Recommendation**: Start with Vercel + Render + MongoDB Atlas (free), scale to AWS/DigitalOcean as you grow.

---

**Last Updated**: January 2024
