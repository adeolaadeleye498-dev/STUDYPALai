# 📚 StudyPal AI - Complete Setup Guide

## Project Overview

**StudyPal AI** is a modern, full-stack AI-powered study assistant platform built with:
- **Frontend**: React + Tailwind CSS (responsive SaaS design)
- **Backend**: Node.js/Express + MongoDB
- **AI Integration**: Anthropic Claude API
- **Authentication**: JWT-based user auth with bcrypt
- **Payments**: Flutterwave/Stripe integration
- **Features**: AI chat tutor, quiz generator, note summarizer, study planner, exam prep, admin dashboard

---

## 🚀 Quick Start (5 Minutes)

### 1. Frontend Setup
```bash
# Create React project
npx create-react-app studypal-ai
cd studypal-ai

# Install dependencies
npm install lucide-react

# Copy the frontend code
# Paste content from: studypal-ai-complete-app.jsx into src/App.jsx

# Start development server
npm start
```
Visit `http://localhost:3000`

### 2. Backend Setup
```bash
# Create backend directory
mkdir studypal-backend
cd studypal-backend

# Copy backend files
# 1. Copy content from backend-server.js to server.js
# 2. Copy content from backend-package.json to package.json
# 3. Create .env file from .env.example

# Install dependencies
npm install

# Start server
npm start
# Server will run on http://localhost:5000
```

---

## 📋 Prerequisites

**Required:**
- Node.js 16.x or higher
- npm 8.x or higher
- MongoDB (Atlas or local)
- Git

**Optional:**
- Docker & Docker Compose
- Postman (for API testing)
- VS Code (recommended editor)

---

## 🛠️ Detailed Installation

### Step 1: Clone & Setup Repository

```bash
git clone https://github.com/yourusername/studypal-ai.git
cd studypal-ai

# Create project directories
mkdir -p frontend backend config
```

### Step 2: Backend Configuration

#### 2.1 Install Backend Dependencies
```bash
cd backend
npm install
```

#### 2.2 Setup MongoDB

**Option A: MongoDB Atlas (Recommended)**
1. Go to https://www.mongodb.com/cloud/atlas
2. Create free account
3. Create cluster
4. Get connection string: `mongodb+srv://username:password@cluster.mongodb.net/studypal`
5. Add it to .env

**Option B: Local MongoDB**
```bash
# Install MongoDB (macOS with Homebrew)
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community

# MongoDB will run on mongodb://localhost:27017
```

#### 2.3 Create .env File
```bash
cp .env.example .env

# Edit .env with your configuration
nano .env
```

**Essential variables:**
```
MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/studypal
JWT_SECRET=your-super-secret-key-change-this
ANTHROPIC_API_KEY=sk-ant-...your-key...
PORT=5000
NODE_ENV=development
```

#### 2.4 Test Backend
```bash
npm start
# You should see: ✅ Connected to MongoDB
#                  ✅ Server running on http://localhost:5000
```

### Step 3: Frontend Configuration

#### 3.1 Create React App
```bash
npx create-react-app studypal-frontend
cd studypal-frontend
```

#### 3.2 Install Dependencies
```bash
npm install lucide-react axios
```

#### 3.3 Update API Configuration

Create `src/config/api.js`:
```javascript
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: `${API_BASE_URL}/api/auth/login`,
    SIGNUP: `${API_BASE_URL}/api/auth/signup`,
  },
  TUTOR: {
    ASK: `${API_BASE_URL}/api/tutor/ask`,
    HISTORY: `${API_BASE_URL}/api/tutor/history`,
  },
  QUIZ: {
    GENERATE: `${API_BASE_URL}/api/quiz/generate`,
    SUBMIT: `${API_BASE_URL}/api/quiz/submit`,
  },
  PLANNER: {
    GENERATE: `${API_BASE_URL}/api/planner/generate`,
    PLANS: `${API_BASE_URL}/api/planner/plans`,
  },
  ADMIN: {
    STATS: `${API_BASE_URL}/api/admin/stats`,
    ANALYTICS: `${API_BASE_URL}/api/admin/analytics`,
    USERS: `${API_BASE_URL}/api/admin/users`,
  },
};
```

#### 3.4 Update .env.local
```
REACT_APP_API_URL=http://localhost:5000
REACT_APP_ANTHROPIC_API_KEY=sk-ant-...
```

#### 3.5 Start Frontend
```bash
npm start
# Runs on http://localhost:3000
```

---

## 🔐 Authentication Flow

### User Registration
```
User clicks "Sign Up"
  ↓
Enters email, password, name
  ↓
POST /api/auth/signup
  ↓
Backend: Hash password with bcrypt (10 rounds)
  ↓
Save user to MongoDB
  ↓
Generate JWT token (7 days expiry)
  ↓
Return user data + token
  ↓
Store token in localStorage
  ↓
Redirect to dashboard
```

### User Login
```
User enters email, password
  ↓
POST /api/auth/login
  ↓
Backend: Compare password hash
  ↓
If match: Generate JWT token
  ↓
Return user + token
  ↓
Store in localStorage
  ↓
Send token with future requests in Authorization header
```

### Protected Routes
```javascript
// Frontend: Add token to headers
const headers = {
  'Authorization': `Bearer ${localStorage.getItem('token')}`
};

// Backend: Verify token with authenticateToken middleware
const authenticateToken = (req, res, next) => {
  const token = req.headers.authorization.split(' ')[1];
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid token' });
    req.user = user;
    next();
  });
};
```

---

## 🤖 AI Integration with Claude

### Setup Anthropic API

1. **Get API Key**
   - Go to https://console.anthropic.com
   - Create account and generate API key
   - Add to .env: `ANTHROPIC_API_KEY=sk-ant-...`

2. **Install SDK**
   ```bash
   npm install @anthropic-ai/sdk
   ```

3. **Backend Implementation**
   ```javascript
   const Anthropic = require('@anthropic-ai/sdk');
   const client = new Anthropic({
     apiKey: process.env.ANTHROPIC_API_KEY
   });

   async function askClaude(question, level) {
     const message = await client.messages.create({
       model: 'claude-3-5-sonnet-20241022',
       max_tokens: 1024,
       messages: [{
         role: 'user',
         content: `Explain at ${level} level: ${question}`
       }]
     });
     return message.content[0].text;
   }
   ```

4. **Test in Backend**
   ```bash
   # Create test-claude.js
   node test-claude.js
   ```

---

## 💳 Payment Integration

### Flutterwave Setup

1. **Get Keys**
   - Register at https://dashboard.flutterwave.com
   - Get public & secret keys
   - Add to .env

2. **Frontend Payment**
   ```javascript
   // Initiate payment
   FlutterwaveCheckout({
     public_key: 'FLWPUBK_...',
     tx_ref: `TXN_${Date.now()}`,
     amount: 2999,
     currency: 'NGN',
     payment_options: 'card,ussd,account_transfer',
     customer: { email: user.email },
     customizations: { title: 'StudyPal Premium' },
     callback: (response) => { /* handle response */ }
   });
   ```

3. **Backend Verification**
   ```javascript
   const axios = require('axios');
   
   async function verifyFlutterwavePayment(transactionId) {
     const response = await axios.get(
       `https://api.flutterwave.com/v3/transactions/${transactionId}/verify`,
       {
         headers: {
           Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`
         }
       }
     );
     return response.data;
   }
   ```

---

## 📊 Database Schema

### User Collection
```javascript
{
  _id: ObjectId,
  name: String,
  email: String (unique),
  password: String (hashed),
  plan: String ('Free' | 'Premium'),
  dailyQuestions: Number,
  totalQuestions: Number,
  isAdmin: Boolean,
  joinedAt: Date,
  subscriptionExpiresAt: Date,
  chatHistory: [{
    question: String,
    answer: String,
    date: Date
  }],
  quizzes: [{
    topicName: String,
    score: Number,
    totalQuestions: Number,
    date: Date
  }],
  studyPlans: [{
    name: String,
    subjects: [String],
    createdAt: Date
  }]
}
```

### Payment Collection
```javascript
{
  _id: ObjectId,
  userId: ObjectId,
  amount: Number,
  plan: String,
  status: String ('pending' | 'completed' | 'failed'),
  transactionId: String,
  paymentMethod: String,
  createdAt: Date
}
```

---

## 🧪 API Testing

### Using cURL

```bash
# Signup
curl -X POST http://localhost:5000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"pass123","name":"John"}'

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"pass123"}'

# Ask question (requires token)
curl -X POST http://localhost:5000/api/tutor/ask \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"question":"What is photosynthesis?","level":"beginner"}'

# Get admin stats
curl -X GET http://localhost:5000/api/admin/stats \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

### Using Postman

1. Import collection: `postman-collection.json`
2. Set environment variables:
   - `base_url`: http://localhost:5000
   - `token`: Your JWT token (from login response)
3. Run requests

---

## 🐳 Docker Setup

### Create Dockerfile
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 5000

CMD ["npm", "start"]
```

### Create docker-compose.yml
```yaml
version: '3.8'
services:
  api:
    build: ./backend
    ports:
      - "5000:5000"
    environment:
      - MONGODB_URI=mongodb://mongo:27017/studypal
      - NODE_ENV=production
    depends_on:
      - mongo
  
  mongo:
    image: mongo:6.0
    ports:
      - "27017:27017"
    volumes:
      - mongo_data:/data/db
  
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"

volumes:
  mongo_data:
```

### Run with Docker
```bash
docker-compose up -d
# API: http://localhost:5000
# Frontend: http://localhost:3000
# MongoDB: localhost:27017
```

---

## 🚀 Deployment

### Deploy Backend (Render)

1. Connect GitHub repository to Render
2. Create Web Service
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables in dashboard
6. Deploy

### Deploy Frontend (Vercel)

1. Connect GitHub to Vercel
2. Framework: Create React App
3. Add `REACT_APP_API_URL` in environment
4. Deploy automatically

### Deploy MongoDB Atlas

Already configured - just use connection string in production

---

## 📈 Performance Optimization

### Frontend
- Code splitting with React.lazy()
- Image optimization
- Minification in production build
- CDN for static assets

```bash
npm run build  # Creates optimized production build
```

### Backend
- Connection pooling for MongoDB
- Request caching with Redis (optional)
- Rate limiting: 100 requests/15 minutes
- GZIP compression

```javascript
const compression = require('compression');
const rateLimit = require('express-rate-limit');

app.use(compression());
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
}));
```

---

## 🔒 Security Best Practices

### Implemented
- ✅ Password hashing with bcrypt
- ✅ JWT token authentication
- ✅ CORS protection
- ✅ Rate limiting
- ✅ SQL/NoSQL injection prevention
- ✅ XSS protection with Helmet

### To Add
```javascript
const helmet = require('helmet');
const mongoSanitize = require('mongo-sanitize');

app.use(helmet());
app.use(mongoSanitize());
```

---

## 📝 API Endpoints

### Authentication
- `POST /api/auth/signup` - Register new user
- `POST /api/auth/login` - User login

### AI Tutor
- `POST /api/tutor/ask` - Ask question to AI
- `GET /api/tutor/history` - Get chat history

### Quiz
- `POST /api/quiz/generate` - Generate quiz
- `POST /api/quiz/submit` - Submit quiz answers

### Study Planner
- `POST /api/planner/generate` - Generate study plan
- `GET /api/planner/plans` - Get user's plans

### Summarizer
- `POST /api/summarizer/summarize` - Summarize notes

### Subscription
- `POST /api/subscription/upgrade` - Upgrade to premium
- `POST /api/subscription/cancel` - Cancel subscription

### Admin
- `GET /api/admin/stats` - Get dashboard statistics
- `GET /api/admin/analytics` - Get analytics
- `GET /api/admin/users` - Get all users

---

## 🐛 Troubleshooting

### MongoDB Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:27017

Solution: 
- Check MongoDB is running
- Verify MONGODB_URI in .env
- For Atlas: whitelist your IP
```

### JWT Verification Failed
```
Error: Invalid signature

Solution:
- Ensure JWT_SECRET is same in .env
- Check token hasn't expired
- Verify Authorization header format: "Bearer TOKEN"
```

### CORS Error
```
Error: Access to XMLHttpRequest blocked by CORS policy

Solution:
- Add frontend URL to ALLOWED_ORIGINS in .env
- Check CORS middleware is initialized
```

### Claude API Key Invalid
```
Error: Invalid authentication credentials

Solution:
- Verify API key in .env
- Check key hasn't been rotated
- Ensure it's from https://console.anthropic.com
```

---

## 📚 Project Structure

```
studypal-ai/
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── App.jsx
│   │   └── index.js
│   └── package.json
├── backend/
│   ├── models/
│   ├── routes/
│   ├── middleware/
│   ├── controllers/
│   ├── server.js
│   ├── package.json
│   └── .env
├── docs/
│   └── API.md
└── README.md
```

---

## 🤝 Contributing

1. Create feature branch: `git checkout -b feature/amazing`
2. Commit changes: `git commit -m 'Add amazing feature'`
3. Push to branch: `git push origin feature/amazing`
4. Open Pull Request

---

## 📄 License

MIT License - See LICENSE.md for details

---

## 💬 Support

- **Documentation**: https://docs.studypal.ai
- **Email**: support@studypal.ai
- **Discord**: https://discord.gg/studypal
- **Issues**: GitHub Issues

---

## 🎯 Roadmap

- [ ] Mobile app (React Native)
- [ ] Video explanations
- [ ] Live study groups
- [ ] AI-generated practice papers
- [ ] Parent/teacher dashboard
- [ ] WhatsApp integration
- [ ] Offline mode
- [ ] Advanced analytics

---

**Last Updated**: 2024
**Version**: 1.0.0
