// ============================================================================
// BACKEND API - server.js
// ============================================================================
// Run: node server.js
// Requirements: npm install express cors dotenv mongoose bcryptjs jsonwebtoken

const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const bcryptjs = require('bcryptjs');
const jwt = require('jsonwebtoken');

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// ============================================================================
// DATABASE MODELS
// ============================================================================

// User Schema
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  plan: { type: String, enum: ['Free', 'Premium'], default: 'Free' },
  dailyQuestions: { type: Number, default: 0 },
  totalQuestions: { type: Number, default: 0 },
  isAdmin: { type: Boolean, default: false },
  joinedAt: { type: Date, default: Date.now },
  subscriptionExpiresAt: Date,
  chatHistory: [{ question: String, answer: String, date: Date }],
  quizzes: [{ topicName: String, score: Number, totalQuestions: Number, date: Date }],
  studyPlans: [{ name: String, subjects: [String], createdAt: Date }],
}, { timestamps: true });

// Payment Schema
const paymentSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  amount: Number,
  plan: String,
  status: { type: String, enum: ['pending', 'completed', 'failed'], default: 'pending' },
  transactionId: String,
  paymentMethod: String,
  createdAt: { type: Date, default: Date.now },
});

// Analytics Schema
const analyticsSchema = new mongoose.Schema({
  date: { type: Date, default: Date.now },
  totalUsers: Number,
  activeUsers: Number,
  totalQuestions: Number,
  premiumSubscriptions: Number,
  revenue: Number,
});

// Initialize Models
const User = mongoose.model('User', userSchema);
const Payment = mongoose.model('Payment', paymentSchema);
const Analytics = mongoose.model('Analytics', analyticsSchema);

// ============================================================================
// AUTHENTICATION MIDDLEWARE
// ============================================================================

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key', (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid token' });
    req.user = user;
    next();
  });
};

const adminOnly = (req, res, next) => {
  if (!req.user.isAdmin) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

// ============================================================================
// ROUTES - AUTHENTICATION
// ============================================================================

// Sign Up
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    const hashedPassword = await bcryptjs.hash(password, 10);
    const user = new User({
      name: name || email.split('@')[0],
      email,
      password: hashedPassword,
      plan: 'Free',
      dailyQuestions: 0,
    });

    await user.save();

    const token = jwt.sign(
      { id: user._id, email: user.email, isAdmin: user.isAdmin },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '7d' }
    );

    res.status(201).json({
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        plan: user.plan,
        isAdmin: user.isAdmin,
      },
      token,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const passwordMatch = await bcryptjs.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = jwt.sign(
      { id: user._id, email: user.email, isAdmin: user.isAdmin },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '7d' }
    );

    res.json({
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        plan: user.plan,
        dailyQuestions: user.dailyQuestions,
        isAdmin: user.isAdmin,
      },
      token,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// ROUTES - AI CHAT TUTOR
// ============================================================================

// Ask a question to AI tutor
app.post('/api/tutor/ask', authenticateToken, async (req, res) => {
  try {
    const { question, level } = req.body;
    const userId = req.user.id;

    // Check daily limit for free users
    const user = await User.findById(userId);
    if (user.plan === 'Free' && user.dailyQuestions >= 10) {
      return res.status(403).json({
        error: 'Daily limit reached',
        message: 'You have reached your free daily limit of 10 questions. Upgrade to Premium for unlimited access.',
      });
    }

    // Call Claude API here (use node SDK)
    const answer = await generateAIResponse(question, level);

    // Save to chat history
    user.chatHistory.push({
      question,
      answer,
      date: new Date(),
    });

    if (user.plan === 'Free') {
      user.dailyQuestions += 1;
    }
    user.totalQuestions += 1;

    await user.save();

    res.json({
      question,
      answer,
      dailyQuestionsUsed: user.dailyQuestions,
      totalQuestions: user.totalQuestions,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get chat history
app.get('/api/tutor/history', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('chatHistory');
    res.json(user.chatHistory);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// ROUTES - QUIZ GENERATOR
// ============================================================================

// Generate quiz
app.post('/api/quiz/generate', authenticateToken, async (req, res) => {
  try {
    const { topic, numQuestions, level } = req.body;

    // Call Claude API to generate quiz
    const quiz = await generateQuizWithAI(topic, numQuestions, level);

    res.json(quiz);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Submit quiz and get score
app.post('/api/quiz/submit', authenticateToken, async (req, res) => {
  try {
    const { topic, answers, totalQuestions } = req.body;
    const userId = req.user.id;

    // Calculate score
    let correctAnswers = 0;
    answers.forEach(answer => {
      if (answer.isCorrect) correctAnswers++;
    });

    const score = Math.round((correctAnswers / totalQuestions) * 100);

    // Save quiz result
    const user = await User.findById(userId);
    user.quizzes.push({
      topicName: topic,
      score: correctAnswers,
      totalQuestions,
      date: new Date(),
    });
    await user.save();

    res.json({
      score: correctAnswers,
      total: totalQuestions,
      percentage: score,
      feedback: generateFeedback(score),
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// ROUTES - STUDY PLANNER
// ============================================================================

// Generate study plan
app.post('/api/planner/generate', authenticateToken, async (req, res) => {
  try {
    const { subjects, hoursPerDay, examDate, priority } = req.body;
    const userId = req.user.id;

    // Call Claude API to generate study plan
    const plan = await generateStudyPlanWithAI(subjects, hoursPerDay, examDate, priority);

    // Save plan
    const user = await User.findById(userId);
    user.studyPlans.push({
      name: `${subjects.join(', ')} - ${priority}`,
      subjects,
      createdAt: new Date(),
    });
    await user.save();

    res.json(plan);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get study plans
app.get('/api/planner/plans', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('studyPlans');
    res.json(user.studyPlans);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// ROUTES - NOTE SUMMARIZER
// ============================================================================

// Summarize notes
app.post('/api/summarizer/summarize', authenticateToken, async (req, res) => {
  try {
    const { notes } = req.body;

    // Call Claude API to summarize
    const summary = await summarizeNotesWithAI(notes);

    res.json({
      originalWordCount: notes.split(' ').length,
      summary: summary.text,
      summaryWordCount: summary.text.split(' ').length,
      keyPoints: summary.keyPoints,
      compressionRate: Math.round(
        ((notes.length - summary.text.length) / notes.length) * 100
      ),
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// ROUTES - SUBSCRIPTION/PAYMENTS
// ============================================================================

// Upgrade to premium
app.post('/api/subscription/upgrade', authenticateToken, async (req, res) => {
  try {
    const { paymentMethod } = req.body;
    const userId = req.user.id;

    // Process payment (integrate with Flutterwave/PayPal)
    const payment = new Payment({
      userId,
      amount: 2999, // ₦2,999
      plan: 'Premium',
      status: 'completed',
      paymentMethod,
      transactionId: `TXN_${Date.now()}`,
    });

    await payment.save();

    // Update user subscription
    const user = await User.findById(userId);
    user.plan = 'Premium';
    user.subscriptionExpiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days
    await user.save();

    res.json({
      success: true,
      message: 'Successfully upgraded to Premium',
      user: { plan: user.plan, subscriptionExpiresAt: user.subscriptionExpiresAt },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Cancel subscription
app.post('/api/subscription/cancel', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    user.plan = 'Free';
    user.subscriptionExpiresAt = null;
    await user.save();

    res.json({ success: true, message: 'Subscription cancelled' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// ROUTES - ADMIN DASHBOARD
// ============================================================================

// Get dashboard statistics
app.get('/api/admin/stats', authenticateToken, adminOnly, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const premiumUsers = await User.countDocuments({ plan: 'Premium' });
    const totalQuestions = await User.aggregate([
      { $group: { _id: null, total: { $sum: '$totalQuestions' } } },
    ]);

    const dailyActiveUsers = await User.countDocuments({
      updatedAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
    });

    res.json({
      totalUsers,
      premiumUsers,
      totalQuestions: totalQuestions[0]?.total || 0,
      dailyActiveUsers,
      conversionRate: Math.round((premiumUsers / totalUsers) * 100),
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get analytics
app.get('/api/admin/analytics', authenticateToken, adminOnly, async (req, res) => {
  try {
    const analytics = await Analytics.find().sort({ date: -1 }).limit(30);
    res.json(analytics);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all users
app.get('/api/admin/users', authenticateToken, adminOnly, async (req, res) => {
  try {
    const users = await User.find()
      .select('name email plan joinedAt totalQuestions')
      .sort({ joinedAt: -1 })
      .limit(100);
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ============================================================================
// HELPER FUNCTIONS - AI INTEGRATION
// ============================================================================

async function generateAIResponse(question, level) {
  // In production, integrate with Anthropic SDK:
  // const Anthropic = require('@anthropic-ai/sdk');
  // const client = new Anthropic();
  // 
  // const message = await client.messages.create({
  //   model: 'claude-3-5-sonnet-20241022',
  //   max_tokens: 1024,
  //   messages: [
  //     {
  //       role: 'user',
  //       content: `As an expert tutor, explain this at a ${level} level:\n\n${question}`
  //     }
  //   ]
  // });
  // return message.content[0].text;

  // Mock response for demo
  const responses = {
    beginner: `I'll explain this in simple terms. Think of it like... [Simple explanation based on ${level} level]`,
    intermediate: `Here's a comprehensive explanation with key concepts... [Detailed explanation]`,
    advanced: `Let's dive into the theoretical foundations and practical applications... [Advanced explanation]`,
  };

  return responses[level] || responses.intermediate;
}

async function generateQuizWithAI(topic, numQuestions, level) {
  // Call Claude to generate quiz questions
  // In production, use Anthropic SDK
  return {
    topic,
    level,
    questions: Array.from({ length: numQuestions }, (_, i) => ({
      id: i,
      question: `What is a key concept in ${topic}? (Question ${i + 1})`,
      options: ['Option A', 'Option B', 'Option C', 'Option D'],
      correctAnswer: 'Option B',
      explanation: `This is correct because... [Explanation for ${topic}]`,
    })),
  };
}

async function generateStudyPlanWithAI(subjects, hoursPerDay, examDate, priority) {
  // Call Claude to generate personalized study plan
  const daysUntilExam = Math.ceil(
    (new Date(examDate) - new Date()) / (1000 * 60 * 60 * 24)
  );

  return {
    subjects,
    hoursPerDay,
    daysUntilExam,
    priority,
    schedule: Array.from({ length: Math.min(daysUntilExam, 14) }, (_, i) => ({
      date: new Date(Date.now() + i * 24 * 60 * 60 * 1000).toLocaleDateString(),
      tasks: subjects.map(s => `Study ${s}: ${(hoursPerDay / subjects.length).toFixed(1)} hours`),
    })),
  };
}

async function summarizeNotesWithAI(notes) {
  // Call Claude to summarize notes
  return {
    text: notes.substring(0, Math.floor(notes.length / 3)) + '...',
    keyPoints: [
      'Key concept 1',
      'Key concept 2',
      'Key concept 3',
      'Key concept 4',
    ],
  };
}

function generateFeedback(score) {
  if (score >= 90) return 'Excellent work! You have mastered this topic.';
  if (score >= 75) return 'Great job! Review the areas you missed.';
  if (score >= 60) return 'Good effort. Study the weak areas more.';
  return 'Keep practicing. Review the fundamentals.';
}

// ============================================================================
// DATABASE CONNECTION & SERVER START
// ============================================================================

const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/studypal';

mongoose
  .connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log('✅ Connected to MongoDB');
    app.listen(PORT, () => {
      console.log(`✅ Server running on http://localhost:${PORT}`);
      console.log(`📚 StudyPal AI API ready for requests`);
    });
  })
  .catch(err => {
    console.error('❌ MongoDB connection error:', err);
    process.exit(1);
  });

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

module.exports = app;
