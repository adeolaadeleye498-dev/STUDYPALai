// ============================================================================
// FRONTEND UTILITIES - hooks.js
// ============================================================================
// Custom React hooks for StudyPal AI Frontend

import { useState, useCallback, useEffect } from 'react';

// ============================================================================
// useAuth - Authentication Hook
// ============================================================================

export function useAuth() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('studypal_user');
    const savedToken = localStorage.getItem('studypal_token');
    
    if (savedUser && savedToken) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = useCallback(async (email, password) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) throw new Error('Login failed');

      const data = await response.json();
      localStorage.setItem('studypal_user', JSON.stringify(data.user));
      localStorage.setItem('studypal_token', data.token);
      setUser(data.user);
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const signup = useCallback(async (name, email, password) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });

      if (!response.ok) throw new Error('Signup failed');

      const data = await response.json();
      localStorage.setItem('studypal_user', JSON.stringify(data.user));
      localStorage.setItem('studypal_token', data.token);
      setUser(data.user);
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('studypal_user');
    localStorage.removeItem('studypal_token');
    setUser(null);
  }, []);

  return { user, loading, error, login, signup, logout };
}

// ============================================================================
// useApi - API Call Hook
// ============================================================================

export function useApi(initialUrl) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetch = useCallback(async (url = initialUrl, options = {}) => {
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('studypal_token');
      const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
      };

      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }

      const response = await window.fetch(url, {
        ...options,
        headers,
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const result = await response.json();
      setData(result);
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [initialUrl]);

  return { data, loading, error, fetch };
}

// ============================================================================
// useDailyQuestionLimit - Track Daily Question Limit
// ============================================================================

export function useDailyQuestionLimit() {
  const [questionsUsed, setQuestionsUsed] = useState(0);
  const [maxQuestions] = useState(10);

  useEffect(() => {
    const saved = localStorage.getItem('studypal_daily_questions');
    const lastDate = localStorage.getItem('studypal_last_question_date');
    const today = new Date().toDateString();

    if (lastDate !== today) {
      localStorage.setItem('studypal_daily_questions', '0');
      localStorage.setItem('studypal_last_question_date', today);
      setQuestionsUsed(0);
    } else {
      setQuestionsUsed(parseInt(saved || 0));
    }
  }, []);

  const incrementQuestion = useCallback(() => {
    const newCount = questionsUsed + 1;
    setQuestionsUsed(newCount);
    localStorage.setItem('studypal_daily_questions', newCount.toString());
    return newCount;
  }, [questionsUsed]);

  const canAskQuestion = questionsUsed < maxQuestions;

  return {
    questionsUsed,
    maxQuestions,
    canAskQuestion,
    remainingQuestions: maxQuestions - questionsUsed,
    incrementQuestion,
  };
}

// ============================================================================
// usePagination - Pagination Hook
// ============================================================================

export function usePagination(items, itemsPerPage = 10) {
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = Math.ceil(items.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentItems = items.slice(startIndex, endIndex);

  const goToPage = useCallback((page) => {
    const pageNumber = Math.max(1, Math.min(page, totalPages));
    setCurrentPage(pageNumber);
  }, [totalPages]);

  const nextPage = useCallback(() => {
    goToPage(currentPage + 1);
  }, [currentPage, goToPage]);

  const prevPage = useCallback(() => {
    goToPage(currentPage - 1);
  }, [currentPage, goToPage]);

  return {
    currentPage,
    totalPages,
    currentItems,
    goToPage,
    nextPage,
    prevPage,
    hasNextPage: currentPage < totalPages,
    hasPrevPage: currentPage > 1,
  };
}

// ============================================================================
// useLocalStorage - Persistent State Hook
// ============================================================================

export function useLocalStorage(key, initialValue) {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error('Error reading localStorage:', error);
      return initialValue;
    }
  });

  const setValue = useCallback(
    (value) => {
      try {
        const valueToStore = value instanceof Function ? value(storedValue) : value;
        setStoredValue(valueToStore);
        localStorage.setItem(key, JSON.stringify(valueToStore));
      } catch (error) {
        console.error('Error writing to localStorage:', error);
      }
    },
    [key, storedValue]
  );

  return [storedValue, setValue];
}

// ============================================================================
// useDebounce - Debounce Hook
// ============================================================================

export function useDebounce(value, delay = 500) {
  const [debouncedValue, setDebouncedValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => clearTimeout(handler);
  }, [value, delay]);

  return debouncedValue;
}

// ============================================================================
// useAsync - Async Operation Hook
// ============================================================================

export function useAsync(asyncFunction, immediate = true) {
  const [status, setStatus] = useState('idle');
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  const execute = useCallback(async () => {
    setStatus('pending');
    setData(null);
    setError(null);
    try {
      const response = await asyncFunction();
      setData(response);
      setStatus('success');
      return response;
    } catch (error) {
      setError(error);
      setStatus('error');
    }
  }, [asyncFunction]);

  useEffect(() => {
    if (immediate) {
      execute();
    }
  }, [execute, immediate]);

  return { execute, status, data, error };
}

// ============================================================================
// useWindowSize - Track Window Size Changes
// ============================================================================

export function useWindowSize() {
  const [windowSize, setWindowSize] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 0,
    height: typeof window !== 'undefined' ? window.innerHeight : 0,
  });

  useEffect(() => {
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return windowSize;
}

// ============================================================================
// useMediaQuery - Media Query Hook
// ============================================================================

export function useMediaQuery(query) {
  const [matches, setMatches] = useState(false);

  useEffect(() => {
    const media = window.matchMedia(query);
    if (media.matches !== matches) {
      setMatches(media.matches);
    }

    const listener = () => setMatches(media.matches);
    media.addEventListener('change', listener);
    return () => media.removeEventListener('change', listener);
  }, [matches, query]);

  return matches;
}

// ============================================================================
// useTimer - Timer/Countdown Hook
// ============================================================================

export function useTimer(duration = 60) {
  const [time, setTime] = useState(duration);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setTime((prevTime) => {
        if (prevTime <= 1) {
          setIsRunning(false);
          return 0;
        }
        return prevTime - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning]);

  const start = useCallback(() => setIsRunning(true), []);
  const stop = useCallback(() => setIsRunning(false), []);
  const reset = useCallback(() => {
    setTime(duration);
    setIsRunning(false);
  }, [duration]);

  return { time, isRunning, start, stop, reset };
}

// ============================================================================
// useFetch - Advanced Fetch Hook with Caching
// ============================================================================

const cache = new Map();

export function useFetch(url, options = {}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(!cache.has(url));
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!url) return;

    if (cache.has(url)) {
      setData(cache.get(url));
      return;
    }

    const fetchData = async () => {
      try {
        const token = localStorage.getItem('studypal_token');
        const headers = options.headers || {};
        if (token) {
          headers.Authorization = `Bearer ${token}`;
        }

        const response = await window.fetch(url, { ...options, headers });
        if (!response.ok) throw new Error(`Fetch failed: ${response.status}`);

        const result = await response.json();
        cache.set(url, result);
        setData(result);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [url, options]);

  return { data, loading, error };
}
