import React, { useState, useEffect, useRef } from 'react';
import { Menu, X, Send, Plus, Settings, LogOut, Home, MessageSquare, 
  Zap, BookOpen, Calendar, Award, BarChart3, Users, Loader, Check, 
  Eye, EyeOff, Lock, Mail, User, ChevronRight, ArrowRight } from 'lucide-react';

// ============================================================================
// MAIN APP COMPONENT
// ============================================================================

export default function StudyPalAI() {
  const [currentUser, setCurrentUser] = useState(null);
  const [currentPage, setCurrentPage] = useState('landing');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('studypal_user');
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
      setCurrentPage('dashboard');
    }
  }, []);

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('studypal_user');
    setCurrentPage('landing');
    setIsMobileMenuOpen(false);
  };

  const handleLogin = (user) => {
    setCurrentUser(user);
    localStorage.setItem('studypal_user', JSON.stringify(user));
    setCurrentPage('dashboard');
  };

  const renderPage = () => {
    if (!currentUser) {
      if (currentPage === 'landing') return <LandingPage onNavigate={setCurrentPage} />;
      if (currentPage === 'login') return <LoginPage onLogin={handleLogin} onNavigate={setCurrentPage} />;
      if (currentPage === 'signup') return <SignupPage onSignup={handleLogin} onNavigate={setCurrentPage} />;
    }

    return (
      <div className="flex h-screen bg-slate-950">
        <Sidebar 
          currentUser={currentUser} 
          currentPage={currentPage} 
          onPageChange={setCurrentPage}
          onLogout={handleLogout}
          isMobileOpen={isMobileMenuOpen}
          onMobileToggle={setIsMobileMenuOpen}
        />
        <main className="flex-1 overflow-hidden">
          {currentPage === 'dashboard' && <Dashboard currentUser={currentUser} />}
          {currentPage === 'chat' && <ChatTutor currentUser={currentUser} />}
          {currentPage === 'quiz' && <QuizGenerator currentUser={currentUser} />}
          {currentPage === 'summarizer' && <NoteSummarizer currentUser={currentUser} />}
          {currentPage === 'planner' && <StudyPlanner currentUser={currentUser} />}
          {currentPage === 'exam' && <ExamPrep currentUser={currentUser} />}
          {currentPage === 'admin' && currentUser.isAdmin && <AdminDashboard />}
          {currentPage === 'settings' && <SettingsPage currentUser={currentUser} />}
        </main>
      </div>
    );
  };

  return renderPage();
}

// ============================================================================
// NAVIGATION
// ============================================================================

function Sidebar({ currentUser, currentPage, onPageChange, onLogout, isMobileOpen, onMobileToggle }) {
  return (
    <>
      {/* Mobile Menu Button */}
      <button 
        onClick={() => onMobileToggle(!isMobileOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-slate-800 text-indigo-400 rounded-lg"
      >
        {isMobileOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <aside className={`
        fixed lg:relative w-64 h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 
        border-r border-slate-800 flex flex-col transition-all duration-300 z-40
        ${isMobileOpen ? 'left-0' : '-left-full lg:left-0'}
      `}>
        {/* Logo */}
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Zap size={24} className="text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
                StudyPal
              </h1>
              <p className="text-xs text-slate-400">AI Tutor</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Home },
            { id: 'chat', label: 'AI Tutor', icon: MessageSquare },
            { id: 'quiz', label: 'Quiz Generator', icon: Zap },
            { id: 'summarizer', label: 'Note Summarizer', icon: BookOpen },
            { id: 'planner', label: 'Study Planner', icon: Calendar },
            { id: 'exam', label: 'Exam Prep', icon: Award },
          ].map(item => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onPageChange(item.id);
                  onMobileToggle(false);
                }}
                className={`
                  w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all
                  ${isActive 
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                    : 'text-slate-300 hover:bg-slate-800'
                  }
                `}
              >
                <Icon size={20} />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}

          {currentUser?.isAdmin && (
            <>
              <div className="my-4 border-t border-slate-800" />
              <button
                onClick={() => {
                  onPageChange('admin');
                  onMobileToggle(false);
                }}
                className={`
                  w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all
                  ${currentPage === 'admin'
                    ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-lg shadow-amber-500/30'
                    : 'text-slate-300 hover:bg-slate-800'
                  }
                `}
              >
                <BarChart3 size={20} />
                <span className="font-medium">Admin Dashboard</span>
              </button>
            </>
          )}
        </nav>

        {/* User Section */}
        <div className="p-4 border-t border-slate-800 space-y-3">
          <div className="px-3 py-2 bg-slate-800 rounded-lg">
            <p className="text-xs text-slate-400">Plan</p>
            <p className="text-sm font-bold text-indigo-400">{currentUser?.plan || 'Free'}</p>
            {currentUser?.plan === 'Free' && (
              <p className="text-xs text-slate-400 mt-1">{currentUser?.dailyQuestions || 0}/10 questions</p>
            )}
          </div>
          
          <button
            onClick={() => {
              onPageChange('settings');
              onMobileToggle(false);
            }}
            className="w-full flex items-center gap-3 px-4 py-2 text-slate-300 hover:bg-slate-800 rounded-lg transition-all"
          >
            <Settings size={20} />
            <span>Settings</span>
          </button>
          
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-2 text-red-400 hover:bg-red-950/30 rounded-lg transition-all"
          >
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => onMobileToggle(false)}
        />
      )}
    </>
  );
}

// ============================================================================
// LANDING PAGE
// ============================================================================

function LandingPage({ onNavigate }) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      {/* Navigation */}
      <nav className="fixed w-full top-0 z-40 bg-slate-950/80 backdrop-blur border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Zap size={20} className="text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
              StudyPal AI
            </span>
          </div>
          <div className="flex gap-4">
            <button
              onClick={() => onNavigate('login')}
              className="px-6 py-2 text-slate-300 hover:text-white transition"
            >
              Login
            </button>
            <button
              onClick={() => onNavigate('signup')}
              className="px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:shadow-lg hover:shadow-indigo-500/30 transition"
            >
              Get Started
            </button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-6 inline-block">
            <span className="px-4 py-2 bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 rounded-full text-sm font-semibold">
              🚀 Powered by Advanced AI
            </span>
          </div>
          
          <h1 className="text-5xl sm:text-7xl font-bold mb-6 bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent leading-tight">
            Learn Smarter, Not Harder
          </h1>
          
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Your AI-powered study companion that explains concepts, generates quizzes, and prepares you for WAEC, NECO, and JAMB exams.
          </p>

          <div className="flex gap-4 justify-center mb-16 flex-wrap">
            <button
              onClick={() => onNavigate('signup')}
              className="px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-2xl hover:shadow-indigo-500/40 transition transform hover:scale-105"
            >
              Start Free Trial <ArrowRight size={20} className="inline ml-2" />
            </button>
            <button
              onClick={() => onNavigate('login')}
              className="px-8 py-4 border border-slate-700 text-slate-300 rounded-lg font-semibold hover:bg-slate-800 transition"
            >
              Sign In
            </button>
          </div>

          {/* Feature Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-20">
            {[
              { icon: MessageSquare, title: 'AI Tutor', desc: 'Ask anything, get clear explanations' },
              { icon: Zap, title: 'Quizzes', desc: 'Generate practice questions instantly' },
              { icon: BookOpen, title: 'Summarizer', desc: 'Condense your notes to key points' },
              { icon: Award, title: 'Exam Prep', desc: 'WAEC, NECO, JAMB preparation' },
            ].map((feature, i) => {
              const Icon = feature.icon;
              return (
                <div key={i} className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl hover:border-indigo-500/50 transition group">
                  <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition">
                    <Icon size={24} className="text-white" />
                  </div>
                  <h3 className="font-bold text-white mb-2">{feature.title}</h3>
                  <p className="text-sm text-slate-400">{feature.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-900/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-4 text-white">Simple, Transparent Pricing</h2>
          <p className="text-center text-slate-400 mb-12">Choose the plan that works for you</p>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                name: 'Free',
                price: '₦0',
                features: [
                  '10 questions/day',
                  'Basic explanations',
                  'Limited quizzes',
                  'Community support',
                ],
                cta: 'Get Started',
                highlighted: false,
              },
              {
                name: 'Premium',
                price: '₦2,999',
                period: '/month',
                features: [
                  'Unlimited questions',
                  'Advanced explanations',
                  'Unlimited quizzes',
                  'Personalized study plans',
                  'Priority support',
                  'Offline access',
                ],
                cta: 'Upgrade Now',
                highlighted: true,
              },
            ].map((plan, i) => (
              <div
                key={i}
                className={`p-8 rounded-xl border transition ${
                  plan.highlighted
                    ? 'bg-gradient-to-br from-indigo-600/20 to-purple-600/20 border-indigo-500/50 shadow-xl shadow-indigo-500/20 scale-105'
                    : 'bg-slate-800 border-slate-700'
                }`}
              >
                <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold text-white">{plan.price}</span>
                  {plan.period && <span className="text-slate-400">{plan.period}</span>}
                </div>
                <button
                  onClick={() => window.location.href = '#signup'}
                  className={`w-full py-3 rounded-lg font-semibold mb-8 transition ${
                    plan.highlighted
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:shadow-lg hover:shadow-indigo-500/30'
                      : 'bg-slate-700 text-white hover:bg-slate-600'
                  }`}
                >
                  {plan.cta}
                </button>
                <ul className="space-y-3">
                  {plan.features.map((feature, j) => (
                    <li key={j} className="flex items-center gap-3 text-slate-300">
                      <Check size={20} className="text-indigo-400" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

// ============================================================================
// AUTHENTICATION
// ============================================================================

function LoginPage({ onLogin, onNavigate }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    await new Promise(r => setTimeout(r, 1500));
    
    onLogin({
      id: '1',
      email,
      name: email.split('@')[0],
      plan: 'Free',
      dailyQuestions: 0,
      isAdmin: email === 'admin@studypal.com',
      joinedAt: new Date().toISOString(),
    });
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Zap size={28} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Welcome Back</h1>
          <p className="text-slate-400">Sign in to continue learning</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
              className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none transition"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none transition"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-300"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? <Loader size={20} className="animate-spin" /> : 'Sign In'}
          </button>
        </form>

        <p className="text-center text-slate-400 mt-6">
          Don't have an account?{' '}
          <button
            onClick={() => onNavigate('signup')}
            className="text-indigo-400 hover:text-indigo-300 font-semibold"
          >
            Sign up
          </button>
        </p>

        <div className="mt-6 p-4 bg-slate-800/50 border border-slate-700 rounded-lg">
          <p className="text-xs text-slate-400 text-center">Demo: Use any email and password to sign in</p>
        </div>
      </div>
    </div>
  );
}

function SignupPage({ onSignup, onNavigate }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    await new Promise(r => setTimeout(r, 1500));
    
    onSignup({
      id: Math.random().toString(),
      email,
      name,
      plan: 'Free',
      dailyQuestions: 0,
      isAdmin: false,
      joinedAt: new Date().toISOString(),
    });
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Zap size={28} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Start Learning Today</h1>
          <p className="text-slate-400">Create your free account</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              required
              className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none transition"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
              className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none transition"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Password</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none transition"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-300"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? <Loader size={20} className="animate-spin" /> : 'Create Account'}
          </button>
        </form>

        <p className="text-center text-slate-400 mt-6">
          Already have an account?{' '}
          <button
            onClick={() => onNavigate('login')}
            className="text-indigo-400 hover:text-indigo-300 font-semibold"
          >
            Sign in
          </button>
        </p>
      </div>
    </div>
  );
}

// ============================================================================
// DASHBOARD
// ============================================================================

function Dashboard({ currentUser }) {
  const [stats] = useState({
    totalQuestions: 156,
    quizzesCompleted: 23,
    studyStreak: 7,
    accuracyRate: 85,
  });

  const [recentActivity] = useState([
    { type: 'quiz', title: 'Biology: Photosynthesis', score: 18, total: 20, date: '2 hours ago' },
    { type: 'chat', title: 'Discussed Quantum Physics concepts', date: '5 hours ago' },
    { type: 'summary', title: 'Summarized Economics notes', date: '1 day ago' },
    { type: 'study', title: 'Generated JAMB preparation plan', date: '2 days ago' },
  ]);

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 sm:p-8 space-y-8">
        {/* Welcome Section */}
        <div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
            Welcome back, <span className="bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">{currentUser?.name}</span>!
          </h1>
          <p className="text-slate-400">Here's what you've accomplished this week</p>
        </div>

        {/* Stats Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Questions Asked', value: stats.totalQuestions, icon: MessageSquare, color: 'from-indigo-600 to-indigo-500' },
            { label: 'Quizzes Done', value: stats.quizzesCompleted, icon: Award, color: 'from-purple-600 to-purple-500' },
            { label: 'Study Streak', value: `${stats.studyStreak} days`, icon: Zap, color: 'from-orange-600 to-orange-500' },
            { label: 'Accuracy', value: `${stats.accuracyRate}%`, icon: Check, color: 'from-green-600 to-green-500' },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div key={i} className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl hover:border-slate-600 transition group">
                <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition`}>
                  <Icon size={24} className="text-white" />
                </div>
                <p className="text-sm text-slate-400 mb-1">{stat.label}</p>
                <p className="text-2xl sm:text-3xl font-bold text-white">{stat.value}</p>
              </div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-xl font-bold text-white mb-4">Quick Actions</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: MessageSquare, title: 'Ask a Question', desc: 'Get instant explanations' },
              { icon: Zap, title: 'Start a Quiz', desc: 'Test your knowledge' },
              { icon: BookOpen, title: 'Summarize Notes', desc: 'Condense your materials' },
              { icon: Calendar, title: 'Create Study Plan', desc: 'Organize your learning' },
            ].map((action, i) => {
              const Icon = action.icon;
              return (
                <button key={i} className="p-4 bg-gradient-to-br from-slate-800 to-slate-800/50 border border-slate-700 rounded-lg hover:border-indigo-500/50 hover:bg-slate-800/80 transition text-left group">
                  <Icon size={24} className="text-indigo-400 mb-3 group-hover:scale-110 transition" />
                  <h3 className="font-semibold text-white mb-1">{action.title}</h3>
                  <p className="text-xs text-slate-400">{action.desc}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Recent Activity */}
        <div>
          <h2 className="text-xl font-bold text-white mb-4">Recent Activity</h2>
          <div className="space-y-3">
            {recentActivity.map((activity, i) => (
              <div key={i} className="p-4 bg-slate-800/30 border border-slate-700 rounded-lg flex items-center justify-between hover:bg-slate-800/50 transition">
                <div className="flex-1">
                  <p className="font-semibold text-white">{activity.title}</p>
                  <p className="text-xs text-slate-400 mt-1">{activity.date}</p>
                </div>
                {activity.score && (
                  <div className="text-right">
                    <p className="font-bold text-green-400">{activity.score}/{activity.total}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Upgrade Section */}
        {currentUser?.plan === 'Free' && (
          <div className="p-6 bg-gradient-to-r from-indigo-600/20 to-purple-600/20 border border-indigo-500/50 rounded-xl">
            <h3 className="font-bold text-white mb-2">Unlock Unlimited Learning</h3>
            <p className="text-sm text-slate-300 mb-4">Upgrade to Premium for unlimited questions and advanced features</p>
            <button className="px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition">
              Upgrade to Premium
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// CHAT TUTOR
// ============================================================================

function ChatTutor({ currentUser }) {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'assistant',
      content: 'Hello! I\'m StudyPal AI, your personal study assistant. I can help you with any academic question, explain complex concepts, or help you prepare for exams. What would you like to learn about today?',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [level, setLevel] = useState('intermediate');
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Check daily limit for free users
    if (currentUser?.plan === 'Free' && currentUser?.dailyQuestions >= 10) {
      setMessages(prev => [...prev, {
        id: Date.now(),
        type: 'assistant',
        content: '📊 You have reached your free daily limit of 10 questions. Upgrade to Premium for unlimited access!',
      }]);
      return;
    }

    // Add user message
    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: input,
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    // Simulate API call to Claude
    await new Promise(r => setTimeout(r, 1500));

    const assistantMessage = {
      id: Date.now() + 1,
      type: 'assistant',
      content: generateAIResponse(input, level),
    };

    setMessages(prev => [...prev, assistantMessage]);
    setLoading(false);

    // Update daily question count
    if (currentUser?.plan === 'Free') {
      currentUser.dailyQuestions = (currentUser.dailyQuestions || 0) + 1;
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950">
      {/* Header */}
      <div className="border-b border-slate-800 p-4 sm:p-6">
        <h2 className="text-xl sm:text-2xl font-bold text-white mb-4">AI Tutor</h2>
        <div className="flex gap-2 flex-wrap">
          {['beginner', 'intermediate', 'advanced'].map(lv => (
            <button
              key={lv}
              onClick={() => setLevel(lv)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition ${
                level === lv
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {lv.charAt(0).toUpperCase() + lv.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.map(msg => (
          <div key={msg.id} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-xl lg:max-w-2xl p-4 rounded-lg ${
                msg.type === 'user'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-100'
              }`}
            >
              {msg.content}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-slate-800 text-slate-100 p-4 rounded-lg">
              <div className="flex gap-2">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t border-slate-800 p-4 sm:p-6">
        <div className="max-w-4xl mx-auto flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Ask anything..."
            className="flex-1 px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
          />
          <button
            onClick={handleSendMessage}
            disabled={loading || !input.trim()}
            className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition disabled:opacity-50"
          >
            <Send size={20} />
          </button>
        </div>
        {currentUser?.plan === 'Free' && (
          <p className="text-xs text-slate-400 mt-3 text-center">
            {currentUser?.dailyQuestions || 0}/10 daily questions used
          </p>
        )}
      </div>
    </div>
  );
}

function generateAIResponse(question, level) {
  const responses = {
    beginner: `Think of it like this: imagine you're learning something completely new. Start with the basics, build your understanding step by step, and don't worry about the complex details yet. Here's what you need to know: This is a foundational concept that will help you understand more advanced topics later.`,
    intermediate: `This concept involves several interconnected parts. Let me break it down: First, understand the core principle. Second, see how it connects to related concepts. Third, look at practical examples. This framework will give you a solid understanding of how things work together.`,
    advanced: `This requires understanding the underlying mechanisms and theoretical foundations. The key principles are: intricate relationships between variables, mathematical modeling, edge cases, and real-world applications. Consider how this connects to related theories and systems.`,
  };

  return responses[level] || responses.intermediate;
}

// ============================================================================
// QUIZ GENERATOR
// ============================================================================

function QuizGenerator({ currentUser }) {
  const [topic, setTopic] = useState('');
  const [numQuestions, setNumQuestions] = useState(5);
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleGenerateQuiz = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 2000));
    
    setQuiz(generateQuiz(topic, numQuestions));
    setAnswers({});
    setSubmitted(false);
    setLoading(false);
  };

  const handleSubmitQuiz = () => {
    setSubmitted(true);
  };

  const getScore = () => {
    if (!quiz) return 0;
    let correct = 0;
    quiz.questions.forEach(q => {
      if (answers[q.id] === q.correctAnswer) correct++;
    });
    return correct;
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 sm:p-8 space-y-8">
        {!quiz ? (
          <div className="max-w-2xl">
            <h1 className="text-3xl font-bold text-white mb-6">Quiz Generator</h1>
            
            <div className="space-y-6 bg-slate-800/50 border border-slate-700 rounded-xl p-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Topic</label>
                <input
                  type="text"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="E.g., Photosynthesis, Calculus, World War II"
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Number of Questions</label>
                <div className="flex gap-3">
                  {[5, 10, 15, 20].map(num => (
                    <button
                      key={num}
                      onClick={() => setNumQuestions(num)}
                      className={`px-4 py-2 rounded-lg font-semibold transition ${
                        numQuestions === num
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleGenerateQuiz}
                disabled={loading || !topic.trim()}
                className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader size={20} className="animate-spin" />
                    Generating Quiz...
                  </>
                ) : (
                  <>
                    <Zap size={20} />
                    Generate Quiz
                  </>
                )}
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-3xl font-bold text-white">Quiz: {topic}</h1>
              <button
                onClick={() => setQuiz(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition"
              >
                New Quiz
              </button>
            </div>

            {submitted ? (
              <div className="max-w-2xl">
                <div className="p-8 bg-gradient-to-br from-green-600/20 to-emerald-600/20 border border-green-500/50 rounded-xl mb-6">
                  <h2 className="text-2xl font-bold text-white mb-4">Quiz Complete!</h2>
                  <p className="text-4xl font-bold text-green-400 mb-2">{getScore()}/{quiz.questions.length}</p>
                  <p className="text-slate-300">Score: {Math.round((getScore() / quiz.questions.length) * 100)}%</p>
                </div>

                <div className="space-y-6">
                  {quiz.questions.map(q => (
                    <div key={q.id} className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl">
                      <h3 className="font-semibold text-white mb-4">{q.question}</h3>
                      <div className="space-y-2">
                        {q.options.map((opt, i) => {
                          const letter = String.fromCharCode(65 + i);
                          const isCorrect = opt === q.correctAnswer;
                          const userSelected = answers[q.id] === opt;
                          const isWrong = userSelected && !isCorrect;

                          return (
                            <div
                              key={i}
                              className={`p-3 rounded-lg border transition ${
                                isCorrect
                                  ? 'bg-green-500/20 border-green-500/50 text-green-300'
                                  : isWrong
                                  ? 'bg-red-500/20 border-red-500/50 text-red-300'
                                  : userSelected
                                  ? 'bg-indigo-500/20 border-indigo-500/50'
                                  : 'bg-slate-700/50 border-slate-600'
                              }`}
                            >
                              <span className="font-semibold">{letter}.</span> {opt}
                              {isCorrect && <span className="float-right">✓ Correct</span>}
                              {isWrong && <span className="float-right">✗ Wrong</span>}
                            </div>
                          );
                        })}
                      </div>
                      <p className="text-sm text-slate-400 mt-4 italic">{q.explanation}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="max-w-2xl space-y-6">
                {quiz.questions.map((q, idx) => (
                  <div key={q.id} className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl">
                    <div className="mb-4">
                      <span className="text-sm text-slate-400">Question {idx + 1} of {quiz.questions.length}</span>
                      <h3 className="text-lg font-semibold text-white mt-2">{q.question}</h3>
                    </div>
                    <div className="space-y-2">
                      {q.options.map((opt, i) => {
                        const letter = String.fromCharCode(65 + i);
                        const isSelected = answers[q.id] === opt;

                        return (
                          <button
                            key={i}
                            onClick={() => setAnswers(prev => ({ ...prev, [q.id]: opt }))}
                            className={`w-full p-3 rounded-lg border transition text-left ${
                              isSelected
                                ? 'bg-indigo-600 border-indigo-500 text-white'
                                : 'bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-700'
                            }`}
                          >
                            <span className="font-semibold">{letter}.</span> {opt}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}

                <button
                  onClick={handleSubmitQuiz}
                  className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition"
                >
                  Submit Quiz
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function generateQuiz(topic, numQuestions) {
  const questions = [];
  for (let i = 0; i < numQuestions; i++) {
    questions.push({
      id: i,
      question: `What is a key concept in ${topic}? (Question ${i + 1})`,
      options: ['Option A', 'Option B', 'Option C', 'Option D'],
      correctAnswer: 'Option B',
      explanation: 'This is the correct answer because... ' + topic + ' involves understanding this fundamental principle.',
    });
  }
  return { topic, questions };
}

// ============================================================================
// NOTE SUMMARIZER
// ============================================================================

function NoteSummarizer({ currentUser }) {
  const [notes, setNotes] = useState('');
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSummarize = async () => {
    if (!notes.trim()) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 2000));

    setSummary({
      original: notes,
      summary: generateSummary(notes),
      keyPoints: extractKeyPoints(notes),
      wordCount: notes.split(' ').length,
      summaryWordCount: generateSummary(notes).split(' ').length,
    });
    setLoading(false);
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 sm:p-8 space-y-8">
        <h1 className="text-3xl font-bold text-white">Note Summarizer</h1>

        {!summary ? (
          <div className="grid lg:grid-cols-2 gap-8">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Your Notes</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Paste your notes here..."
                className="w-full h-96 px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none resize-none"
              />
              <p className="text-xs text-slate-400 mt-2">{notes.split(' ').length} words</p>
              
              <button
                onClick={handleSummarize}
                disabled={loading || !notes.trim()}
                className="mt-4 w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader size={20} className="animate-spin" />
                    Summarizing...
                  </>
                ) : (
                  <>
                    <BookOpen size={20} />
                    Summarize Notes
                  </>
                )}
              </button>
            </div>

            <div className="bg-gradient-to-br from-indigo-600/20 to-purple-600/20 border border-indigo-500/50 rounded-xl p-6 h-fit">
              <h3 className="font-bold text-white mb-4">Tips for Better Summaries</h3>
              <ul className="space-y-3 text-sm text-slate-300">
                <li className="flex gap-3">
                  <Check size={16} className="text-indigo-400 mt-0.5 flex-shrink-0" />
                  <span>Use complete sentences in your notes</span>
                </li>
                <li className="flex gap-3">
                  <Check size={16} className="text-indigo-400 mt-0.5 flex-shrink-0" />
                  <span>Include key terms and definitions</span>
                </li>
                <li className="flex gap-3">
                  <Check size={16} className="text-indigo-400 mt-0.5 flex-shrink-0" />
                  <span>Organize information by topics</span>
                </li>
                <li className="flex gap-3">
                  <Check size={16} className="text-indigo-400 mt-0.5 flex-shrink-0" />
                  <span>Add examples when possible</span>
                </li>
              </ul>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-white">Summary Generated</h2>
              <button
                onClick={() => setSummary(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition"
              >
                New Summary
              </button>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              <div className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl">
                <h3 className="font-bold text-white mb-4">Original Notes</h3>
                <p className="text-slate-300 text-sm mb-3">{summary.original}</p>
                <p className="text-xs text-slate-400">{summary.wordCount} words</p>
              </div>

              <div className="p-6 bg-gradient-to-br from-indigo-600/20 to-purple-600/20 border border-indigo-500/50 rounded-xl">
                <h3 className="font-bold text-white mb-4">Summary</h3>
                <p className="text-slate-300 text-sm mb-3">{summary.summary}</p>
                <p className="text-xs text-slate-400">{summary.summaryWordCount} words (Reduced by {Math.round(((summary.wordCount - summary.summaryWordCount) / summary.wordCount) * 100)}%)</p>
              </div>
            </div>

            <div className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl">
              <h3 className="font-bold text-white mb-4">Key Points</h3>
              <ul className="space-y-2">
                {summary.keyPoints.map((point, i) => (
                  <li key={i} className="flex gap-3 text-slate-300">
                    <span className="text-indigo-400 font-bold">{i + 1}.</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function generateSummary(text) {
  const sentences = text.split('.').filter(s => s.trim());
  return sentences.slice(0, Math.max(1, Math.floor(sentences.length / 2))).join('. ').trim() + '.';
}

function extractKeyPoints(text) {
  return [
    'Main concept: Understanding the foundational principles presented',
    'Secondary point: How these concepts relate to broader topics',
    'Application: Practical uses and real-world examples',
    'Important detail: Critical information to remember for exams',
  ];
}

// ============================================================================
// STUDY PLANNER
// ============================================================================

function StudyPlanner({ currentUser }) {
  const [formData, setFormData] = useState({
    subjects: '',
    hoursPerDay: 2,
    examDate: '',
    priority: 'balanced',
  });
  const [plan, setPlan] = useState(null);

  const handleGeneratePlan = async () => {
    if (!formData.subjects || !formData.examDate) return;
    
    const subjects = formData.subjects.split(',').map(s => s.trim());
    setPlan({
      subjects,
      schedule: generateStudySchedule(subjects, formData.hoursPerDay, formData.examDate, formData.priority),
      startDate: new Date().toISOString(),
      examDate: formData.examDate,
    });
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 sm:p-8 space-y-8">
        <h1 className="text-3xl font-bold text-white">Study Planner</h1>

        {!plan ? (
          <div className="max-w-2xl space-y-6 bg-slate-800/50 border border-slate-700 rounded-xl p-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Subjects (comma-separated)</label>
              <input
                type="text"
                value={formData.subjects}
                onChange={(e) => setFormData(prev => ({ ...prev, subjects: e.target.value }))}
                placeholder="E.g., Mathematics, Biology, English"
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Hours Available Per Day</label>
              <select
                value={formData.hoursPerDay}
                onChange={(e) => setFormData(prev => ({ ...prev, hoursPerDay: parseInt(e.target.value) }))}
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:border-indigo-500 focus:outline-none"
              >
                {[1, 2, 3, 4, 5].map(h => <option key={h} value={h}>{h} hour{h > 1 ? 's' : ''}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Exam Date</label>
              <input
                type="date"
                value={formData.examDate}
                onChange={(e) => setFormData(prev => ({ ...prev, examDate: e.target.value }))}
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Study Priority</label>
              <div className="flex gap-3">
                {[
                  { value: 'balanced', label: 'Balanced' },
                  { value: 'weak', label: 'Focus on Weak Areas' },
                  { value: 'intensive', label: 'Intensive' },
                ].map(opt => (
                  <button
                    key={opt.value}
                    onClick={() => setFormData(prev => ({ ...prev, priority: opt.value }))}
                    className={`px-4 py-2 rounded-lg font-semibold transition ${
                      formData.priority === opt.value
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleGeneratePlan}
              className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Calendar size={20} />
              Generate Study Plan
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-white">Your Personalized Study Plan</h2>
              <button
                onClick={() => setPlan(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition"
              >
                Create New Plan
              </button>
            </div>

            <div className="grid sm:grid-cols-3 gap-4">
              {plan.subjects.map((subject, i) => (
                <div key={i} className="p-4 bg-gradient-to-br from-slate-800 to-slate-800/50 border border-slate-700 rounded-lg">
                  <p className="text-sm text-slate-400">Subject</p>
                  <p className="text-lg font-bold text-white">{subject}</p>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              {plan.schedule.map((day, i) => (
                <div key={i} className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl hover:border-indigo-500/50 transition">
                  <h3 className="font-bold text-white mb-3">{day.date}</h3>
                  <div className="space-y-2">
                    {day.tasks.map((task, j) => (
                      <div key={j} className="flex items-center gap-3 p-3 bg-slate-700/50 rounded-lg">
                        <input type="checkbox" className="w-4 h-4 rounded" />
                        <span className="flex-1 text-slate-300">{task}</span>
                        <span className="text-xs text-slate-400">1-2 hrs</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function generateStudySchedule(subjects, hoursPerDay, examDate, priority) {
  const schedule = [];
  const daysUntilExam = 14; // Example: 2 weeks
  
  for (let i = 0; i < Math.min(daysUntilExam, 7); i++) {
    const date = new Date();
    date.setDate(date.getDate() + i);
    
    const daySchedule = {
      date: date.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' }),
      tasks: [],
    };

    // Distribute subjects across days
    const subjectIndex = i % subjects.length;
    daySchedule.tasks = [
      `Review ${subjects[subjectIndex]} fundamentals`,
      `Practice problems in ${subjects[subjectIndex]}`,
      `Quick quiz on ${subjects[subjectIndex]}`,
    ];

    if (priority === 'intensive') {
      daySchedule.tasks.push(`Deep dive: Advanced ${subjects[subjectIndex]} concepts`);
    }

    schedule.push(daySchedule);
  }

  return schedule;
}

// ============================================================================
// EXAM PREP
// ============================================================================

function ExamPrep({ currentUser }) {
  const [selectedExam, setSelectedExam] = useState(null);

  const exams = [
    {
      id: 'waec',
      name: 'WAEC Preparation',
      icon: Award,
      subjects: ['English', 'Mathematics', 'Physics', 'Chemistry', 'Biology'],
      color: 'from-blue-600 to-blue-500',
    },
    {
      id: 'neco',
      name: 'NECO Preparation',
      icon: Award,
      subjects: ['English', 'Mathematics', 'Physics', 'Chemistry', 'Biology'],
      color: 'from-green-600 to-green-500',
    },
    {
      id: 'jamb',
      name: 'JAMB Preparation',
      icon: Award,
      subjects: ['English', 'Mathematics', 'Physics', 'Chemistry'],
      color: 'from-purple-600 to-purple-500',
    },
  ];

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 sm:p-8 space-y-8">
        <h1 className="text-3xl font-bold text-white">Exam Preparation</h1>

        {!selectedExam ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {exams.map(exam => {
              const Icon = exam.icon;
              return (
                <button
                  key={exam.id}
                  onClick={() => setSelectedExam(exam)}
                  className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl hover:border-indigo-500/50 transition text-left group"
                >
                  <div className={`w-12 h-12 bg-gradient-to-br ${exam.color} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition`}>
                    <Icon size={24} className="text-white" />
                  </div>
                  <h3 className="font-bold text-white mb-3">{exam.name}</h3>
                  <div className="flex flex-wrap gap-2">
                    {exam.subjects.slice(0, 3).map((subject, i) => (
                      <span key={i} className="text-xs px-2 py-1 bg-slate-700 text-slate-300 rounded">
                        {subject}
                      </span>
                    ))}
                  </div>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setSelectedExam(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition"
              >
                ← Back
              </button>
              <h2 className="text-2xl font-bold text-white">{selectedExam.name}</h2>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {selectedExam.subjects.map((subject, i) => (
                <div key={i} className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl hover:border-indigo-500/50 transition cursor-pointer group">
                  <h3 className="font-bold text-white mb-3 group-hover:text-indigo-400 transition">{subject}</h3>
                  <div className="space-y-2 text-sm text-slate-400">
                    <p>📚 Theory & Concepts</p>
                    <p>❓ Practice Questions</p>
                    <p>📝 Sample Papers</p>
                  </div>
                  <button className="mt-4 w-full py-2 bg-indigo-600/20 text-indigo-400 rounded-lg hover:bg-indigo-600/30 transition text-sm font-semibold">
                    Start Preparing
                  </button>
                </div>
              ))}
            </div>

            <div className="p-6 bg-gradient-to-br from-indigo-600/20 to-purple-600/20 border border-indigo-500/50 rounded-xl">
              <h3 className="font-bold text-white mb-4">Preparation Tips</h3>
              <ul className="space-y-2 text-slate-300 text-sm">
                <li>✓ Start with weak areas first</li>
                <li>✓ Take regular practice tests</li>
                <li>✓ Review past papers</li>
                <li>✓ Build a consistent study routine</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// SETTINGS
// ============================================================================

function SettingsPage({ currentUser }) {
  const [theme, setTheme] = useState('dark');

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 sm:p-8 space-y-8 max-w-2xl">
        <h1 className="text-3xl font-bold text-white">Settings</h1>

        {/* Account */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-white">Account</h2>
          <div className="space-y-4 bg-slate-800/50 border border-slate-700 rounded-xl p-6">
            <div>
              <p className="text-sm text-slate-400 mb-1">Email</p>
              <p className="font-semibold text-white">{currentUser?.email}</p>
            </div>
            <div>
              <p className="text-sm text-slate-400 mb-1">Joined</p>
              <p className="font-semibold text-white">{new Date(currentUser?.joinedAt).toLocaleDateString()}</p>
            </div>
          </div>
        </div>

        {/* Preferences */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-white">Preferences</h2>
          <div className="space-y-4 bg-slate-800/50 border border-slate-700 rounded-xl p-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-3">Theme</label>
              <div className="flex gap-3">
                {['light', 'dark', 'auto'].map(t => (
                  <button
                    key={t}
                    onClick={() => setTheme(t)}
                    className={`px-4 py-2 rounded-lg font-semibold transition capitalize ${
                      theme === t
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Subscription */}
        {currentUser?.plan === 'Free' && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white">Subscription</h2>
            <div className="p-6 bg-gradient-to-br from-indigo-600/20 to-purple-600/20 border border-indigo-500/50 rounded-xl">
              <p className="text-slate-300 mb-4">You're currently on the Free plan</p>
              <button className="px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-indigo-500/30 transition">
                Upgrade to Premium
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// ADMIN DASHBOARD
// ============================================================================

function AdminDashboard() {
  const [stats] = useState({
    totalUsers: 2543,
    premiumUsers: 358,
    totalQuestions: 124567,
    dailyActiveUsers: 892,
  });

  const [analytics] = useState([
    { date: 'Mon', users: 432, questions: 2341 },
    { date: 'Tue', users: 521, questions: 2891 },
    { date: 'Wed', users: 489, questions: 2156 },
    { date: 'Thu', users: 612, questions: 3214 },
    { date: 'Fri', users: 758, questions: 3891 },
    { date: 'Sat', users: 645, questions: 2987 },
    { date: 'Sun', users: 523, questions: 2654 },
  ]);

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 sm:p-8 space-y-8">
        <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>

        {/* Key Metrics */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'from-blue-600 to-blue-500' },
            { label: 'Premium Users', value: stats.premiumUsers, icon: Users, color: 'from-green-600 to-green-500' },
            { label: 'Questions Asked', value: stats.totalQuestions, icon: MessageSquare, color: 'from-purple-600 to-purple-500' },
            { label: 'Daily Active', value: stats.dailyActiveUsers, icon: Zap, color: 'from-orange-600 to-orange-500' },
          ].map((metric, i) => {
            const Icon = metric.icon;
            return (
              <div key={i} className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl">
                <div className={`w-12 h-12 bg-gradient-to-br ${metric.color} rounded-lg flex items-center justify-center mb-4`}>
                  <Icon size={24} className="text-white" />
                </div>
                <p className="text-sm text-slate-400 mb-1">{metric.label}</p>
                <p className="text-2xl font-bold text-white">{metric.value.toLocaleString()}</p>
              </div>
            );
          })}
        </div>

        {/* Analytics Chart */}
        <div className="p-6 bg-slate-800/50 border border-slate-700 rounded-xl">
          <h2 className="text-xl font-bold text-white mb-6">Weekly Analytics</h2>
          <div className="space-y-6">
            {analytics.map((day, i) => (
              <div key={i} className="space-y-2">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-white">{day.date}</span>
                  <span className="text-sm text-slate-400">{day.questions.toLocaleString()} questions</span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-indigo-600 to-purple-600"
                    style={{ width: `${(day.questions / 4000) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}